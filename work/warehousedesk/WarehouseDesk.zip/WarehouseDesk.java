import com.sun.net.httpserver.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.Executors;
import java.lang.reflect.RecordComponent;

public class WarehouseDesk {
    static final String[] PEOPLE={"Avery Lane","Morgan Reed","Casey Holt","Jamie Vale","Alex Brook","Taylor Finch","Riley Moss","Jordan Dale","Drew Hart","Sam Lake","Blair West","Robin Stone"};
    static final String[] SURNAMES={"Lane","Reed","Holt","Vale","Brook","Finch","Moss","Dale","Hart","Lake","West","Stone","Fox","Hall","King","Wren","Wood","Gray","Hill","Snow"};
    static final String[] SKU={"Oat drink 1 L","Penne 500 g","Tinned tomatoes","Kitchen rolls","Laundry tabs","Shampoo 250 ml","Breakfast oats","Hand soap"};
    enum Task {
        RECEIVE("Receiving",90), PUT("Putaway",75), PICK("Picking",100), DISPATCH("Dispatch",120),
        REPLEN("Replenishment",82), PACK("Packing",95), RETURNS("Returns",44), COUNT("Cycle count",110), QA("Quality inspection",60), BREAK("Break",0), BRIEF("Briefing",0), WAIT("Bay wait",0);
        final String label; final int target;
        Task(String label,int target){this.label=label;this.target=target;}
    }
    record Event(String id,String worker,String task,int start,int end,String from,String to,String sku,int units,int errors,String exception,int target){}
    record Worker(String name,int direct,int breaks,int support,int units,int picks,int errors,double earned){}
    record Case(String id,String category,String description,String priority,String status,String owner,String eventId,int opened,String area,String action){}
    record Report(String date,String shift,int start,List<Event> events,List<Worker> workers,List<Case> cases){}
    static final String[][] CASES={
        {"Health & safety","Pedestrian and pallet truck near miss","High","Safety lead","Traffic layout review"},
        {"Health & safety","Spill in travel aisle","High","Area lead","Aisle inspection"},
        {"Health & safety","Manual handling concern","Medium","Safety lead","Handling assessment"},
        {"Health & safety","Minor first-aid incident","High","Safety lead","Incident review"},
        {"Equipment","Forklift taken out of service","High","Engineering","Maintenance inspection"},
        {"Equipment","Conveyor stoppage","High","Engineering","Fault diagnosis"},
        {"Systems","Handheld scanner offline","Medium","IT support","Device replacement"},
        {"Systems","Delayed scan synchronisation","Medium","Systems lead","Reconcile scan queue"},
        {"Inventory","Stock count variance","Medium","Stock control","Location recount"},
        {"Inventory","Empty pick face","High","Replenishment lead","Review reserve stock"},
        {"Quality","Damaged outer carton","Medium","Quality lead","Inspect affected stock"},
        {"Quality","Unreadable barcode","Medium","Quality lead","Verify product identity"},
        {"Inbound","Supplier delivery discrepancy","Medium","Inbound lead","Reconcile delivery note"},
        {"Outbound","Trailer collection delay","High","Transport lead","Review collection slot"},
        {"Returns","Returned stock awaiting disposition","Low","Returns lead","Review item condition"},
        {"Facilities","Dock door fault","High","Facilities lead","Dock assessment"}
    };
    static Worker summarize(String person,List<Event> events){
        int direct=0,breaks=0,support=0,units=0,picks=0,errors=0; double earned=0;
        for(var e:events){
            if(!e.worker.equals(person)) continue;
            int minutes=e.end-e.start;
            if(e.target>0){direct+=minutes; units+=e.units; earned+=60.0*e.units/e.target;}
            else if(e.task.equals("Break")) breaks+=minutes; else support+=minutes;
            if(e.task.equals("Picking")){picks+=e.units;errors+=e.errors;}
        }
        return new Worker(person,direct,breaks,support,units,picks,errors,earned);
    }
    static Report report(int day,int shift){
        Random rng=new Random(20261101L+day*101+shift);
        int base=shift==0?360:840;
        List<Event> events=new ArrayList<>(); List<Worker> workers=new ArrayList<>();
        String date=LocalDate.of(2026,11,9).plusDays(day).toString();
        for(int w=0;w<120;w++){
            int staff=shift*120+w;
            String person=String.format(Locale.ROOT,"W%03d · %s %s",staff+1,PEOPLE[staff%12].split(" ")[0],SURNAMES[staff/12]);
            int t=0;
            while(t<480){
                int end; Task task;
                if(t==0){task=Task.BRIEF;end=10;}
                else if(t==120||t==300){task=Task.BREAK;end=t+15;}
                else if(t==210){task=Task.WAIT;end=t+5+rng.nextInt(16);}
                else{
                    task=switch(w%20){case 0,1,2 -> Task.RECEIVE;case 3,4 -> Task.PUT;case 5,6 -> Task.DISPATCH;case 7,8 -> Task.REPLEN;case 9,10 -> Task.PACK;case 11 -> Task.RETURNS;case 12 -> Task.COUNT;case 13 -> Task.QA;default -> Task.PICK;};
                    int boundary=t<120?120:t<210?210:t<300?300:480;
                    end=Math.min(boundary,t+8+rng.nextInt(20));
                }
                String from="",to="",sku="",issue=""; int units=0,errors=0;
                if(task.target>0){
                    String bay="Bay "+(1+rng.nextInt(4)),rack="Rack "+(1+rng.nextInt(24)),lane="Lane "+(1+rng.nextInt(6));
                    from=switch(task){case RECEIVE -> "Inbound trailer";case PUT -> bay;case PICK,COUNT,REPLEN -> rack;case RETURNS -> "Returns bay";case QA -> "Inspection bench"; default -> lane;};
                    to=switch(task){case RECEIVE -> bay;case PUT -> rack;case PICK -> lane;case REPLEN -> "Pick face "+(1+rng.nextInt(30));case PACK -> "Dispatch lane";case COUNT -> rack;case RETURNS,QA -> "Review area";default -> "Store load "+(1+rng.nextInt(8));};
                    sku=SKU[rng.nextInt(SKU.length)];
                    units=Math.max(1,(int)Math.round((end-t)*task.target/60.0*(0.75+0.5*rng.nextDouble())));
                    if(task==Task.PICK && rng.nextDouble()<0.18){errors=1;issue=rng.nextBoolean()?"Wrong SKU corrected":"Quantity corrected";}
                }
                String id=String.format(Locale.ROOT,"D%02d-%s-%04d",day+1,shift==0?"E":"L",events.size()+1);
                events.add(new Event(id,person,task.label,base+t,base+end,from,to,sku,units,errors,issue,task.target));
                t=end;
            }
            workers.add(summarize(person,events));
        }
        events.sort(Comparator.comparingInt(Event::start).thenComparing(Event::id));
        List<Case> cases=new ArrayList<>();
        for(int i=0;i<CASES.length;i++){
            String[] item=CASES[i];
            String activity=switch(i){case 4,9->"Replenishment";case 5,11->"Packing";case 8->"Cycle count";case 10->"Quality inspection";case 12,15->"Receiving";case 13->"Dispatch";case 14->"Returns";default->"Picking";};
            var eligible=events.stream().filter(e->e.task.equals(activity)).toList();
            var event=eligible.get(rng.nextInt(eligible.size()));
            String status=List.of("Open","Under review","Closed").get(rng.nextInt(3));
            cases.add(new Case("C-"+event.id+"-"+(i+1),item[0],item[1],item[2],status,item[3],event.id,event.end,event.from,item[4]));
        }
        return new Report(date,shift==0?"Early":"Late",base,events,workers,cases);
    }
    // The encoder accepts only the project's records, lists, strings and numbers.
    static String json(Object o){
        if(o instanceof String s) return "\""+s.replace("\\","\\\\").replace("\"","\\\"")+"\"";
        if(o instanceof Number) return o.toString();
        StringJoiner j;
        if(o instanceof List<?> list){j=new StringJoiner(",","[","]");for(var item:list) j.add(json(item));return j.toString();}
        j=new StringJoiner(",","{","}");
        for(RecordComponent c:o.getClass().getRecordComponents()){
            try{j.add(json(c.getName())+":"+json(c.getAccessor().invoke(o)));}
            catch(ReflectiveOperationException e){throw new IllegalStateException(e);}
        }
        return j.toString();
    }
    static void send(HttpExchange ex,int status,String type,byte[] bytes)throws IOException{
        ex.getResponseHeaders().set("Content-Type",type);
        ex.sendResponseHeaders(status,bytes.length);
        try(var stream=ex.getResponseBody()){stream.write(bytes);}
    }
    static void handle(HttpExchange ex,List<Report> reports,Path web)throws IOException{
        String path=ex.getRequestURI().getPath();
        if(!ex.getRequestMethod().equals("GET")){send(ex,405,"text/plain","GET required".getBytes());return;}
        if(path.equals("/api/reports")){send(ex,200,"application/json",json(reports.stream().map(r->r.date+"/"+r.shift.toLowerCase(Locale.ROOT)).toList()).getBytes(StandardCharsets.UTF_8));return;}
        if(path.startsWith("/api/reports/")){
            for(var r:reports)if(path.equals("/api/reports/"+r.date+"/"+r.shift.toLowerCase(Locale.ROOT))){
                send(ex,200,"application/json",json(r).getBytes(StandardCharsets.UTF_8));return;
            }
        }
        String file=switch(path){case "/", "/dashboard.html" -> "dashboard.html";case "/app.js" -> "app.js";case "/style.css" -> "style.css";default -> "";};
        if(file.isEmpty()){send(ex,404,"text/plain","Unknown resource".getBytes());return;}
        String mime=file.endsWith(".js")?"text/javascript":file.endsWith(".css")?"text/css":"text/html";
        send(ex,200,mime+"; charset=utf-8",Files.readAllBytes(web.resolve(file)));
    }
    public static void main(String[] args)throws Exception{
        List<Report> reports=new ArrayList<>();
        for(int d=0;d<5;d++)for(int s=0;s<2;s++)reports.add(report(d,s));
        if(args.length==2 && args[0].equals("export")){
            Path dest=Path.of(args[1]);Files.createDirectories(dest);
            for(var r:reports) Files.writeString(dest.resolve(r.date+"-"+r.shift.toLowerCase(Locale.ROOT)+".json"),json(r));
            return;
        }
        var server=HttpServer.create(new InetSocketAddress("127.0.0.1",args.length==0?8080:Integer.parseInt(args[0])),0);
        server.createContext("/",ex->handle(ex,reports,Path.of("web")));
        server.setExecutor(Executors.newVirtualThreadPerTaskExecutor());server.start();
        System.out.println("WarehouseDesk running at http://127.0.0.1:"+server.getAddress().getPort());
    }
}
