# WarehouseDesk
A Java 21 retail distribution reporting application with a browser interface. Includes a deterministic five-day scenario for 240 fictional colleagues, two eight-hour shifts and nine operational activities. No external dependencies, accounts or installation of a database required.

## Run
From this directory with JDK 21 installed, run:
```sh
java WarehouseDesk.java
```
Open http://127.0.0.1:8080/. Supply a port as the first argument to change it. To run the optional integration checks while the server is running, use `python3 verify.py`. Stop the server with Ctrl+C.

## Reporting model
The Java application generates timestamped event records, aggregates colleague time and task-weighted performance, attaches site incidents to activities, and serves the UI and read-only JSON endpoints. GET /api/reports lists the available shifts. GET /api/reports/2026-11-09/early returns one report. The dashboard calculates shift totals and drills down into the returned events. The portfolio edition loads exports of these same API records. Regenerate them with `java WarehouseDesk.java export snapshots`.

- First-pass picking accuracy = (picked units − corrected units) / picked units. All simulated pick units are checked. A zero denominator is displayed as a dash.
- Productivity = processed units / direct labour hours. Receiving, picking and dispatch totals describe separate stages and may count the same physical unit at different stages. The mixed-task unit rate should be interpreted with the activity mix in view.
- Performance = standard minutes earned / actual direct minutes. For each activity, earned minutes = quantity × 60 / that activity's fictional hourly standard.
- An employee's direct, break and support minutes cover the full eight-hour shift. The ledger contains batch movements and timed activities, including briefings and waits.
- Each shift contains 16 illustrated incident scenarios. Case types recur deliberately for coverage. Case status is the shift-end snapshot. These counts do not estimate real incident frequency.
- The generator models activity reporting. It does not reconcile inventory balances, individual serial numbers, or downstream shipment lineage. Data is read-only and regenerated deterministically. No integration with a live WMS, HR system or employee monitoring source is used.
