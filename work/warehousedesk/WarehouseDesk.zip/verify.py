"""Integration checks. Start WarehouseDesk first, then run python3 verify.py [port]."""
import json
import sys
from collections import Counter
from urllib.request import urlopen
from urllib.error import HTTPError

base = 'http://127.0.0.1:' + (sys.argv[1] if len(sys.argv)>1 else '8080')
def get(path):
    with urlopen(base + path) as response:
        return response.read()

paths=json.loads(get('/api/reports'))
assert len(set(paths))==10
staff=set()
events_count=0
for path in paths:
    r=json.loads(get('/api/reports/'+path))
    events=r['events']
    by_id={e['id']:e for e in events}
    assert len(by_id)==len(events)
    assert len(r['workers'])==120
    for c in r['cases']:
        linked=by_id[c['eventId']]
        assert c['opened']==linked['end'] and c['area']==linked['from']
    for w in r['workers']:
        staff.add(w['name'])
        timeline=[e for e in events if e['worker']==w['name']]
        cursor=r['start']
        minutes=Counter()
        for e in timeline:
            assert e['start']==cursor and e['end']>cursor
            minutes['direct' if e['target'] else 'breaks' if e['task']=='Break' else 'support']+=e['end']-cursor
            cursor=e['end']
        assert cursor==r['start']+480
        assert all(w[k]==minutes[k] for k in ('direct','breaks','support'))
        assert w['breaks']==30
        assert sum(e['units'] for e in timeline)==w['units']
        assert sum(e['units'] for e in timeline if e['task']=='Picking')==w['picks']
        assert sum(e['errors'] for e in timeline)==w['errors']<=w['picks']
        assert abs(sum(60*e['units']/e['target'] for e in timeline if e['target'])-w['earned'])<1e-8
    events_count+=len(events)
assert len(staff)==240
for path in ['/','/style.css','/app.js']:
    assert get(path)
try:
    get('/api/reports/missing')
    raise AssertionError('Missing shift returned success')
except HTTPError as exc:
    assert exc.code==404
print(f'Passed: 10 shift reports, {len(staff)} colleagues and {events_count:,} events.')
