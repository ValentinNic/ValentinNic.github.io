import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  Boxes,
  Banknote,
  Clock3,
  Moon,
  UsersRound,
  SlidersHorizontal,
  Download,
  RotateCcw,
  Plus,
  Search,
  Pencil,
  Trash2,
  X,
  Copy,
  Check,
  Calculator,
  Wallet,
  Building2,
} from "lucide-react";

const KEY = "logistics-finance-payroll.v1";
const departments = ["Fleet", "Dispatch", "Warehouse", "Operations"];
const currencyCodes = { "£": "GBP", $: "USD", "€": "EUR" };
const defaults = {
  multiplier: 1.5,
  mode: "percent",
  percent: 20,
  fixed: 3,
  hours: 160,
  currency: "£",
};
const demo = [
  ["fleet-1", "Elliot Hayes", "HGV Class 1 Driver", "Fleet", 3200, 12, 24],
  ["dispatch-1", "Amira Shah", "Night Dispatcher", "Dispatch", 2850, 8, 96],
  [
    "warehouse-1",
    "Theo Brooks",
    "Forklift Operator",
    "Warehouse",
    2600,
    10,
    16,
  ],
  ["ops-1", "Grace Morgan", "Dock Supervisor", "Operations", 3400, 6, 32],
  [
    "warehouse-2",
    "Nadia Ellis",
    "Warehouse Operative",
    "Warehouse",
    2400,
    14,
    20,
  ],
];
function seed() {
  return {
    settings: { ...defaults },
    employees: demo.map(([id, name, role, department, salary, ot, night]) => ({
      id,
      name,
      role,
      department,
      salary,
      ot,
      night,
    })),
  };
}
const scaled = (n) => Math.round(n * 100);
const numeric = (n, min, max) =>
  typeof n === "number" &&
  Number.isFinite(n) &&
  n >= min &&
  n <= max &&
  Math.abs(n * 100 - scaled(n)) < 0.00001;
function validState(s) {
  const r = s?.settings;
  return (
    r &&
    numeric(r.multiplier, 0, 10) &&
    numeric(r.hours, 1, 1000) &&
    numeric(r.percent, 0, 1000) &&
    numeric(r.fixed, 0, 10000) &&
    Object.hasOwn(currencyCodes, r.currency) &&
    ["percent", "fixed"].includes(r.mode) &&
    Array.isArray(s.employees) &&
    s.employees.every(
      (e) =>
        e &&
        typeof e.id === "string" &&
        e.id &&
        typeof e.name === "string" &&
        e.name.trim() &&
        typeof e.role === "string" &&
        e.role.trim() &&
        departments.includes(e.department) &&
        numeric(e.salary, 0, 1000000) &&
        numeric(e.ot, 0, 1000) &&
        numeric(e.night, 0, 1000),
    ) &&
    new Set(s.employees.map((e) => e.id)).size === s.employees.length
  );
}
function load() {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw === null) return { state: seed(), notice: "" };
    const state = JSON.parse(raw);
    if (!validState(state)) throw Error();
    return { state, notice: "" };
  } catch {
    return {
      state: seed(),
      notice: "Saved data could not be loaded. A fresh demo is open.",
    };
  }
}
// Inputs are scaled to hundredths; round each pay component once, half up.
function roundRatio(numerator, denominator) {
  return Number((2n * numerator + denominator) / (2n * denominator));
}
export function wage(e, s) {
  const base = BigInt(scaled(e.salary)),
    hours = BigInt(scaled(s.hours)),
    nightHours = BigInt(scaled(e.night));
  const overtime = roundRatio(
    base * BigInt(scaled(e.ot)) * BigInt(scaled(s.multiplier)),
    hours * 100n,
  );
  const premium =
    s.mode === "percent"
      ? roundRatio(
          base * nightHours * BigInt(scaled(s.percent)),
          hours * 10000n,
        )
      : roundRatio(nightHours * BigInt(scaled(s.fixed)), 100n);
  return {
    base: Number(base),
    hourly: e.salary / s.hours,
    overtime,
    premium,
    gross: Number(base) + overtime + premium,
  };
}
const money = (minor, currency) =>
  new Intl.NumberFormat("en-GB", {
    style: "currency",
    currency: currencyCodes[currency],
  }).format(minor / 100);
const fmt = (n) => n.toLocaleString("en-GB", { maximumFractionDigits: 2 });
const initials = (name) =>
  name
    .trim()
    .split(/\s+/)
    .filter((_, i, a) => i === 0 || i === a.length - 1)
    .map((w) => Array.from(w)[0])
    .join("")
    .toUpperCase();
function breakdown(e, s) {
  const w = wage(e, s),
    cash = (n) => money(n, s.currency);
  const rate =
    s.currency + w.hourly.toLocaleString("en-GB", { maximumFractionDigits: 6 });
  return [
    [
      "Base hourly rate",
      cash(w.base) + " ÷ " + fmt(s.hours) + " standard hours",
      rate + "/h",
    ],
    [
      "Overtime pay",
      fmt(e.ot) + " h × (" + rate + " × " + fmt(s.multiplier) + ")",
      cash(w.overtime),
    ],
    [
      "Night shift premium",
      s.mode === "percent"
        ? fmt(e.night) + " h × (" + rate + " × " + fmt(s.percent) + "%)"
        : fmt(e.night) + " h × " + cash(scaled(s.fixed)) + "/h",
      cash(w.premium),
    ],
    [
      "Total gross wage",
      cash(w.base) +
        " base + " +
        cash(w.overtime) +
        " overtime + " +
        cash(w.premium) +
        " night premium",
      cash(w.gross),
    ],
  ];
}
export function csvFor(rows, s) {
  const unit = s.currency,
    header = [
      "Employee",
      "Role",
      "Department",
      "Base salary (" + unit + ")",
      "OT hours",
      "Overtime pay (" + unit + ")",
      "Night hours",
      "Night premium (" + unit + ")",
      "Gross wage (" + unit + ")",
    ];
  const records = rows.map((e) => {
    const w = wage(e, s);
    return [
      e.name,
      e.role,
      e.department,
      (w.base / 100).toFixed(2),
      e.ot,
      (w.overtime / 100).toFixed(2),
      e.night,
      (w.premium / 100).toFixed(2),
      (w.gross / 100).toFixed(2),
    ];
  });
  function cell(v) {
    let str = String(v);
    if (/^[\s]*[=+@-]|^[\t\r\n]/.test(str)) str = "'" + str;
    return '"' + str.replaceAll('"', '""') + '"';
  }
  return (
    "\uFEFF" +
    [header, ...records].map((row) => row.map(cell).join(",")).join("\r\n")
  );
}
function download(rows, s) {
  const url = URL.createObjectURL(
    new Blob([csvFor(rows, s)], { type: "text/csv;charset=utf-8;" }),
  );
  const a = document.createElement("a");
  a.href = url;
  a.download =
    "logistics-payroll-" + new Date().toISOString().slice(0, 10) + ".csv";
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
function RateInput({ label, value, onChange, min = 0, max, unit }) {
  const [draft, setDraft] = useState(String(value));
  useEffect(() => setDraft(String(value)), [value]);
  return (
    <label className="rate-label">
      <span>{label}</span>
      <div className="input-unit">
        <input
          aria-label={label}
          type="number"
          step=".01"
          min={min}
          max={max}
          required
          value={draft}
          onChange={(e) => {
            const v = e.target.value;
            setDraft(v);
            if (v !== "" && numeric(Number(v), min, max)) onChange(Number(v));
          }}
          onBlur={() => setDraft(String(value))}
        />
        <span>{unit}</span>
      </div>
    </label>
  );
}
function Choices({ label, items, value, change }) {
  return (
    <div className="choices" role="group" aria-label={label}>
      {items.map(([v, text]) => (
        <button
          key={v}
          type="button"
          aria-pressed={value === v}
          onClick={() => change(v)}
        >
          {text}
        </button>
      ))}
    </div>
  );
}
function Rates({ s, change }) {
  return (
    <section className="panel rates">
      <div className="panel-heading">
        <SlidersHorizontal />
        <h2>Finance rate controls</h2>
      </div>
      <div className="rate-grid">
        <div>
          <RateInput
            label="Overtime multiplier"
            value={s.multiplier}
            max={10}
            unit="×"
            onChange={(v) => change("multiplier", v)}
          />
          <Choices
            label="Overtime presets"
            value={s.multiplier}
            items={[
              [1.25, "1.25x"],
              [1.5, "1.5x"],
              [2, "2.0x"],
            ]}
            change={(v) => change("multiplier", v)}
          />
        </div>
        <div>
          <RateInput
            key={s.mode}
            label="Night shift premium"
            value={s[s.mode]}
            max={s.mode === "percent" ? 1000 : 10000}
            unit={s.mode === "percent" ? "%" : s.currency + "/h"}
            onChange={(v) => change(s.mode, v)}
          />
          <Choices
            label="Night premium mode"
            value={s.mode}
            items={[
              ["percent", "% Base"],
              ["fixed", "Fixed/h"],
            ]}
            change={(v) => change("mode", v)}
          />
        </div>
        <div>
          <RateInput
            label="Standard monthly hours"
            value={s.hours}
            min={1}
            max={1000}
            unit="hrs/mo"
            onChange={(v) => change("hours", v)}
          />
          <small>Used to calculate base hourly rates.</small>
        </div>
        <div>
          <span className="field-label">Payroll currency</span>
          <Choices
            label="Payroll currency"
            value={s.currency}
            items={Object.keys(currencyCodes).map((k) => [k, k])}
            change={(v) => change("currency", v)}
          />
          <small>Display currency. Amounts stay the same.</small>
        </div>
      </div>
    </section>
  );
}
function Metric({ label, value, detail, icon: Icon, featured }) {
  return (
    <article className={"metric " + (featured ? "featured" : "")}>
      <div className="metric-label">
        <Icon aria-hidden="true" size={17} />
        {label}
      </div>
      <strong>{value}</strong>
      <small>{detail}</small>
    </article>
  );
}
function Modal({ title, children, close }) {
  const ref = useRef(null);
  useEffect(() => {
    const dialog = ref.current;
    dialog.showModal();
    return () => dialog.close();
  }, []);
  return (
    <dialog
      ref={ref}
      aria-labelledby="modal-title"
      onCancel={(e) => {
        e.preventDefault();
        close();
      }}
    >
      <div className="modal-head">
        <h2 id="modal-title">{title}</h2>
        <button className="icon" aria-label="Close dialog" onClick={close}>
          <X />
        </button>
      </div>
      {children}
    </dialog>
  );
}
const blank = {
  name: "",
  role: "",
  department: "Fleet",
  salary: "",
  ot: "0",
  night: "0",
};
function EmployeeForm({ initial, s, save, close }) {
  const [d, set] = useState(initial ? { ...initial } : blank);
  const [error, setError] = useState("");
  const change = (k, v) => set((prev) => ({ ...prev, [k]: v }));
  const employee = {
    ...d,
    name: d.name.trim(),
    role: d.role.trim(),
    salary: Number(d.salary),
    ot: Number(d.ot),
    night: Number(d.night),
  };
  const numbers = ["salary", "ot", "night"].every(
    (k) =>
      d[k] !== "" && numeric(employee[k], 0, k === "salary" ? 1000000 : 1000),
  );
  function submit(ev) {
    ev.preventDefault();
    if (!employee.name || !employee.role || !numbers) {
      setError("Enter a name, role and valid pay and hour values.");
      return;
    }
    save({ ...employee, id: initial?.id || crypto.randomUUID() });
  }
  return (
    <Modal title={initial ? "Edit employee" : "Add employee"} close={close}>
      <form onSubmit={submit}>
        <div className="form-grid">
          {[
            ["name", "Full name"],
            ["role", "Role"],
          ].map(([key, label]) => (
            <label key={key}>
              {label}
              <input
                required
                maxLength={100}
                value={d[key]}
                onChange={(e) => change(key, e.target.value)}
              />
            </label>
          ))}
          <label>
            Department
            <select
              value={d.department}
              onChange={(e) => change("department", e.target.value)}
            >
              {departments.map((t) => (
                <option key={t}>{t}</option>
              ))}
            </select>
          </label>
          {[
            ["salary", "Monthly base salary (" + s.currency + ")"],
            ["ot", "Overtime hours"],
            ["night", "Night shift hours"],
          ].map(([key, label]) => (
            <label key={key}>
              {label}
              <input
                type="number"
                min="0"
                max={key === "salary" ? 1000000 : 1000}
                step=".01"
                required
                value={d[key]}
                onChange={(e) => change(key, e.target.value)}
              />
            </label>
          ))}
        </div>
        <div className="projected">
          <span>
            <Calculator size={17} />
            Projected gross wage
          </span>
          <strong>
            {numbers ? money(wage(employee, s).gross, s.currency) : "—"}
          </strong>
        </div>
        {error && <p role="alert">{error}</p>}
        <div className="modal-actions">
          <button className="outline" type="button" onClick={close}>
            Cancel
          </button>
          <button className="primary">
            {initial ? "Save changes" : "Add employee"}
          </button>
        </div>
      </form>
    </Modal>
  );
}
function Payslip({ e, s, close }) {
  const rows = breakdown(e, s);
  const [copied, setCopied] = useState(false),
    [fallback, setFallback] = useState(false);
  const text = [
    "Gross wage breakdown",
    e.name + " · " + e.role + " · " + e.department,
    ...rows.map(([k, f, v]) => k + ": " + f + " = " + v),
    "Hourly rates are displayed to six decimals. Pay components use the full rate and round to the nearest cent or penny.",
  ].join("\n");
  async function copy() {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
    } catch {
      setFallback(true);
    }
  }
  return (
    <Modal title="Payslip breakdown" close={close}>
      <div className="person slip-person">
        <span className="avatar">{initials(e.name)}</span>
        <div>
          <strong>{e.name}</strong>
          <small>
            {e.role} · {e.department}
          </small>
        </div>
      </div>
      <dl className="calculations">
        {rows.map(([k, f, v]) => (
          <div key={k}>
            <dt>{k}</dt>
            <dd>
              <span>{f}</span>
              <b>{v}</b>
            </dd>
          </div>
        ))}
      </dl>
      <p className="muted">
        Hourly rates are shown to six decimal places. Pay uses the full rate and
        rounds each component to the nearest cent or penny.
      </p>
      {fallback && (
        <label>
          Copy the selected breakdown
          <textarea
            autoFocus
            readOnly
            onFocus={(ev) => ev.target.select()}
            value={text}
          />
        </label>
      )}
      <div className="modal-actions">
        <button className="outline" onClick={close}>
          Close
        </button>
        <button className="primary" onClick={copy}>
          {copied ? <Check /> : <Copy />}
          {copied ? "Copied" : "Copy breakdown"}
        </button>
      </div>
    </Modal>
  );
}
export default function App() {
  const [initial] = useState(load),
    [state, setState] = useState(initial.state),
    [notice, setNotice] = useState(initial.notice);
  const [dep, setDep] = useState("All"),
    [search, setSearch] = useState(""),
    [modal, setModal] = useState(null),
    [reset, setReset] = useState(false),
    [message, setMessage] = useState("");
  const { employees, settings: s } = state;
  const [storageIssue, setStorageIssue] = useState(false);
  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(state));
      setStorageIssue(false);
    } catch {
      setStorageIssue(true);
    }
  }, [state]);
  useEffect(() => {
    if (!message) return;
    const id = setTimeout(() => setMessage(""), 3200);
    return () => clearTimeout(id);
  }, [message]);
  const all = useMemo(
    () => employees.map((e) => ({ ...e, pay: wage(e, s) })),
    [employees, s],
  );
  const visible = all.filter(
    (e) =>
      (dep === "All" || e.department === dep) &&
      [e.name, e.role, e.department].some((v) =>
        v.toLowerCase().includes(search.trim().toLowerCase()),
      ),
  );
  const sum = (k) => all.reduce((t, e) => t + e.pay[k], 0);
  const hours = (k) => all.reduce((t, e) => t + scaled(e[k]), 0) / 100;
  const gross = sum("gross"),
    base = sum("base"),
    cash = (n) => money(n, s.currency);
  const selected = employees.find((e) => e.id === modal?.id);
  const close = () => setModal(null);
  function save(employee) {
    setState((prev) => ({
      ...prev,
      employees:
        modal?.type === "edit"
          ? prev.employees.map((e) => (e.id === employee.id ? employee : e))
          : [...prev.employees, employee],
    }));
    setDep("All");
    setSearch("");
    close();
    setMessage("Employee saved.");
  }
  function resetData() {
    setState(seed());
    setDep("All");
    setSearch("");
    setNotice("");
    setReset(false);
    setMessage("Demo payroll restored.");
  }
  return (
    <div className="bg-slate-50 min-h-screen tabular-nums">
      <a className="skip" href="#roster">
        Skip to roster
      </a>
      <header className="bg-slate-900 text-white">
        <div className="wrap brand-bar">
          <div className="brand">
            <span className="brand-icon bg-emerald-500">
              <Boxes size={22} />
            </span>
            <span>
              Logistics Finance <em>&amp; Payroll</em>
            </span>
          </div>
          <span className="demo-tag">
            <i />
            Demo workspace
          </span>
        </div>
      </header>
      <main className="wrap">
        <div className="page-head">
          <div>
            <p className="eyebrow">Monthly payroll</p>
            <h1>Payroll overview</h1>
            <p>
              Review gross wages and model shift costs across your workforce.
            </p>
          </div>
          <div className="actions">
            {reset ? (
              <>
                <button className="outline" onClick={() => setReset(false)}>
                  Cancel reset
                </button>
                <button className="danger" onClick={resetData}>
                  Confirm reset
                </button>
              </>
            ) : (
              <button className="plain" onClick={() => setReset(true)}>
                <RotateCcw />
                Reset demo
              </button>
            )}
            <button
              className="outline"
              onClick={() => {
                download(visible, s);
                setMessage("Exported " + visible.length + " employee records.");
              }}
            >
              <Download />
              Export CSV
            </button>
          </div>
        </div>
        {notice && <p role="alert">{notice}</p>}
        {storageIssue && (
          <p role="alert">
            Browser storage is unavailable. Changes last for this session.
          </p>
        )}
        <div className="metrics">
          <Metric
            label="Total gross payroll"
            value={cash(gross)}
            detail={
              all.length +
              " active " +
              (all.length === 1 ? "employee" : "employees")
            }
            icon={Wallet}
            featured
          />
          <Metric
            label="Total base salaries"
            value={cash(base)}
            detail={
              (gross ? fmt((base / gross) * 100) : "0") + "% of gross payroll"
            }
            icon={Banknote}
          />
          <Metric
            label="Overtime pay"
            value={cash(sum("overtime"))}
            detail={fmt(hours("ot")) + " overtime hours"}
            icon={Clock3}
          />
          <Metric
            label="Night premium pay"
            value={cash(sum("premium"))}
            detail={fmt(hours("night")) + " night hours"}
            icon={Moon}
          />
        </div>
        <Rates
          s={s}
          change={(k, v) =>
            setState((prev) => ({
              ...prev,
              settings: { ...prev.settings, [k]: v },
            }))
          }
        />
        <section className="panel roster" id="roster">
          <div className="roster-head">
            <div>
              <div className="panel-heading">
                <UsersRound />
                <h2>Employee roster</h2>
              </div>
              <p>Select an employee to see their pay calculation.</p>
            </div>
            <button
              className="primary"
              onClick={() => setModal({ type: "add" })}
            >
              <Plus />
              Add employee
            </button>
          </div>
          <div className="toolbar">
            <div
              className="pills"
              aria-label="Filter by department"
              role="group"
            >
              {["All", ...departments].map((d) => (
                <button
                  key={d}
                  aria-pressed={dep === d}
                  onClick={() => setDep(d)}
                >
                  {d}
                </button>
              ))}
            </div>
            <label className="search">
              <Search size={16} />
              <input
                type="search"
                aria-label="Search employees"
                placeholder="Search employees…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </label>
          </div>
          <div
            className="table-scroll"
            role="region"
            aria-label="Employee payroll table"
            tabIndex="0"
          >
            <table>
              <thead>
                <tr>
                  {[
                    "Employee",
                    "Department",
                    "Base salary",
                    "OT hours",
                    "Night hours",
                    "Gross wage",
                    "Actions",
                  ].map((h) => (
                    <th scope="col" key={h}>
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {visible.map((e) => (
                  <tr
                    key={e.id}
                    onClick={() => setModal({ type: "slip", id: e.id })}
                  >
                    <td>
                      <button
                        className="person person-btn"
                        aria-label={"Open payslip for " + e.name}
                        onClick={(ev) => {
                          ev.stopPropagation();
                          setModal({ type: "slip", id: e.id });
                        }}
                      >
                        <span className={"avatar dept-" + e.department}>
                          {initials(e.name)}
                        </span>
                        <span>
                          <strong>{e.name}</strong>
                          <small>{e.role}</small>
                        </span>
                      </button>
                    </td>
                    <td>
                      <span className={"badge dept-" + e.department}>
                        {e.department}
                      </span>
                    </td>
                    <td>{cash(e.pay.base)}</td>
                    <td>
                      {fmt(e.ot)} h<small>{cash(e.pay.overtime)}</small>
                    </td>
                    <td>
                      {fmt(e.night)} h<small>{cash(e.pay.premium)}</small>
                    </td>
                    <td className="gross">{cash(e.pay.gross)}</td>
                    <td>
                      <div className="row-actions">
                        {[
                          ["edit", Pencil],
                          ["delete", Trash2],
                        ].map(([action, Icon]) => (
                          <button
                            className={"icon " + action}
                            key={action}
                            aria-label={action + " " + e.name}
                            onClick={(ev) => {
                              ev.stopPropagation();
                              setModal({ type: action, id: e.id });
                            }}
                          >
                            <Icon size={16} />
                          </button>
                        ))}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {!visible.length && (
            <div className="empty">
              <Building2 />
              <strong>
                {employees.length
                  ? "No matching employees"
                  : "Your roster is empty"}
              </strong>
              <p>
                {employees.length
                  ? "Change the search or department filter."
                  : "Add an employee to calculate monthly pay."}
              </p>
            </div>
          )}
          <div className="table-foot">
            <span>
              Showing {visible.length} of {employees.length} employees
            </span>
            <span>
              Filtered gross{" "}
              <b>{cash(visible.reduce((t, e) => t + e.pay.gross, 0))}</b>
            </span>
          </div>
        </section>
        <footer>
          Simulated payroll · Monthly gross wages before deductions
        </footer>
      </main>
      {modal?.type === "add" && (
        <EmployeeForm s={s} save={save} close={close} />
      )}
      {modal?.type === "edit" && selected && (
        <EmployeeForm initial={selected} s={s} save={save} close={close} />
      )}
      {modal?.type === "slip" && selected && (
        <Payslip e={selected} s={s} close={close} />
      )}
      {modal?.type === "delete" && selected && (
        <Modal title="Remove employee?" close={close}>
          <p className="delete-text">
            Remove {selected.name} from the roster and monthly payroll totals?
          </p>
          <div className="modal-actions">
            <button className="outline" onClick={close}>
              Cancel
            </button>
            <button
              className="danger"
              onClick={() => {
                setState((prev) => ({
                  ...prev,
                  employees: prev.employees.filter((e) => e.id !== selected.id),
                }));
                close();
                setMessage("Employee removed.");
              }}
            >
              Delete employee
            </button>
          </div>
        </Modal>
      )}
      <div role="status" className={message ? "toast" : "sr-only"}>
        {message}
      </div>
    </div>
  );
}
