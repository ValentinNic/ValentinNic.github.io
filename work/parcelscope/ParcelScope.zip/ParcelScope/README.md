# ParcelScope

A reproducible parcel-volume forecasting project for weekly depot planning, by Valentin.

**Open index.html in a browser** to explore the finished dashboard offline. Select a depot and a time window, inspect the forecast band and review the five largest daily misses. The CSV exports and Python source are included.

![ParcelScope backtest results](portfolio-card.png)

## The planning question

On Monday morning, how many parcels should each depot expect on each of the next seven days? Underestimating demand can leave too few people on shift. Overestimating it can leave unused capacity. This project models parcel counts. Translating counts into staffing would require productivity and shift data.

## Design and evaluation

The seeded simulator creates 3,276 daily observations across three fictional depots over 156 weeks. Each series combines weekday patterns, growth, annual seasonality, known promotions, persistent demand shocks and count noise. The dataset contains exactly one row per depot and calendar day. The lag implementation relies on that regularity.

Each depot gets a ridge regression with weekday indicators, an annual sine/cosine pair, a time trend, a scheduled promotion flag and demand from seven and fourteen days earlier. These lags are available for every horizon when the weekly forecast is issued. A seasonal naïve benchmark uses the same weekday in the previous week.

The initial 132 weeks supply model history. Over the next 12 Mondays the expanding-window backtest collects forecast errors. Each depot’s 90th percentile absolute error sets a fixed band radius. The final 12 Mondays form the evaluation period. Models refit on history available at each origin while the interval radii remain fixed. There is no random train/test split.

| Final 12 weeks | Ridge MAE | Benchmark MAE | Band coverage |
|---|---:|---:|---:|
| Central | 77.5 | 171.8 | 91.7% |
| Coast | 50.7 | 100.8 | 85.7% |
| North | 52.3 | 116.7 | 86.9% |
| All depot-days | 60.2 | 129.8 | 88.1% |

MAE is mean absolute error in parcels per depot-day. Pooled WAPE is the sum of absolute errors divided by total observed volume (4.26%). Across 252 held-out depot-days the model reduced MAE by 53.6% relative to the benchmark. The band missed its 90% target overall, particularly at Coast. The flat depot-specific radius can understate uncertainty on high-volume days.

These figures describe a synthetic experiment. The model and simulator share calendar and promotion patterns. Real operational validation would require time-stamped promotion plans, missing-day handling and testing through disruptions.

## Reproduce with Python 3.12

From the extracted project folder, run:

```bash
python -m venv .venv
```

Activate the environment with `.venv\Scripts\activate.bat` in Windows Command Prompt or `source .venv/bin/activate` on macOS/Linux. Then run:

```bash
python -m pip install -r requirements.txt
python -m unittest discover -v
python -m parcelscope.build
```

The build regenerates the dashboard, the full daily dataset, all held-out predictions and the metrics. GitHub Actions runs the tests and build on pushes and pull requests.

## Project map

| Path | Purpose |
|---|---|
| parcelscope/model.py | Simulation, feature engineering, weekly forecasting, calibration and evaluation |
| parcelscope/build.py | Reproducible build and data export |
| parcelscope/dashboard.html | Offline dashboard template |
| tests/test_forecast.py | Reproducibility, future-count leakage, benchmark alignment and output checks |
| output/daily_volume.csv | Date, depot, scheduled promotion flag and observed parcel count |
| output/backtest.csv | Observed counts, model and benchmark predictions, bounds and promotion flags |
| output/metrics.json | Pooled and per-depot metrics |
| LINKEDIN.md | Suggested post and profile project description |
| portfolio-card.png | Shareable image of the measured results |

## Share the project

Extract the ZIP and upload the contents of the ParcelScope folder to a GitHub repository. Keep index.html at the repository root. To host the interactive version, serve that folder with a static web host such as GitHub Pages. Add the resulting project URL to the LinkedIn draft and attach portfolio-card.png.
