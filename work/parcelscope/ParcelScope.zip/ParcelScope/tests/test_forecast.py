import unittest

import pandas as pd

from parcelscope.model import backtest, features, forecast, simulate


class ForecastTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = simulate()
        cls.frame = features(cls.raw)
        cls.test = backtest(cls.frame)

    def test_simulation_is_reproducible_and_complete(self):
        pd.testing.assert_frame_equal(self.raw, simulate())
        self.assertFalse(self.raw.duplicated(["depot", "date"]).any())
        self.assertEqual(len(self.raw), 3 * 156 * 7)

    def test_forecast_does_not_read_future_counts(self):
        origin = self.raw.date.max() - pd.Timedelta(days=6)
        changed = self.raw.copy()
        changed.loc[changed.date >= origin, "parcels"] = 999999
        actual = forecast(features(changed), origin)
        expected = forecast(self.frame, origin)
        pd.testing.assert_series_equal(actual.prediction, expected.prediction)

    def test_baseline_is_exactly_one_week_old(self):
        previous = self.raw.set_index(["depot", "date"]).parcels
        for r in self.test.itertuples():
            self.assertEqual(r.lag7, previous[r.depot, r.date - pd.Timedelta(days=7)])

    def test_evaluation_scope_and_bands(self):
        self.assertEqual(self.test.date.min().weekday(), 0)
        self.assertEqual(len(self.test), 252)
        self.assertEqual(self.test.date.nunique(), 84)
        self.assertTrue(self.test.prediction.between(self.test.lower, self.test.upper).all())
