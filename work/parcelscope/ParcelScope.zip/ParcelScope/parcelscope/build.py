"""Rebuild the offline dashboard, example dataset and evaluation from source."""
import json
from pathlib import Path

from .model import backtest, features, metrics, simulate

ROOT = Path(__file__).resolve().parents[1]


def main():
    out = ROOT / "output"
    out.mkdir(exist_ok=True)
    data = simulate()
    data.to_csv(out / "daily_volume.csv", index=False)
    test = backtest(features(data)).sort_values(["date", "depot"])
    report = {"pooled": metrics(test), "by_depot": {k: metrics(v) for k, v in test.groupby("depot")}}
    (out / "metrics.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    cols = ["date", "depot", "parcels", "prediction", "lag7", "lower", "upper", "promotion"]
    result = test[cols].copy()
    result["date"] = result.date.dt.strftime("%Y-%m-%d")
    result.to_csv(out / "backtest.csv", index=False)
    template = (ROOT / "parcelscope" / "dashboard.html").read_text(encoding="utf-8")
    (ROOT / "index.html").write_text(template.replace("__ROWS__", result.to_json(orient="records")), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
