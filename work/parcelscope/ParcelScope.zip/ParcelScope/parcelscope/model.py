"""Weekly planning with a fixed Monday forecast origin."""
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

DEPOTS = {"North": 1020, "Central": 1450, "Coast": 780}
CATEGORIES = ["depot", "weekday"]
NUMERIC = ["day", "annual_sin", "annual_cos", "promotion", "lag7", "lag14"]


def simulate(seed=41):
    rng = np.random.default_rng(seed)
    dates = pd.date_range("2023-01-02", periods=7 * 156)
    rows = []
    for depot, base in DEPOTS.items():
        shock = 0.0
        for day, date in enumerate(dates):
            promotion = int(rng.random() < 0.12)
            weekday = [1.20, 1.10, 1.04, 1.02, 1.13, 0.76, 0.50][date.weekday()]
            season = 0.12 * np.cos(2 * np.pi * (day + 25) / 365.25)
            shock = 0.55 * shock + rng.normal(0, 0.045)
            mean = base * (weekday + season + day * 0.00019 + promotion * 0.32 + shock)
            rows.append((date, depot, promotion, int(rng.poisson(max(1, mean)))))
    return pd.DataFrame(rows, columns=["date", "depot", "promotion", "parcels"])


def features(data):
    frame = data.sort_values(["depot", "date"]).copy()
    frame["day"] = (frame.date - pd.Timestamp("2023-01-02")).dt.days
    frame["weekday"] = frame.date.dt.dayofweek
    phase = frame.day * 2 * np.pi / 365.25
    frame["annual_sin"] = np.sin(phase)
    frame["annual_cos"] = np.cos(phase)
    series = frame.groupby("depot").parcels
    for lag in (7, 14):
        frame[f"lag{lag}"] = series.shift(lag)
    return frame.dropna(subset=["lag7", "lag14"])


def forecast(frame, origin):
    train = frame[frame.date < origin]
    week = frame[frame.date.between(origin, origin + pd.Timedelta(days=6))].copy()
    transform = ColumnTransformer([
        ("category", OneHotEncoder(handle_unknown="ignore"), CATEGORIES),
        ("numeric", StandardScaler(), NUMERIC),
    ])
    # Fit per depot so weekly amplitudes and promotion effects can differ.
    parts = []
    for depot, target in week.groupby("depot"):
        history = train[train.depot == depot]
        model = make_pipeline(transform, Ridge(alpha=3))
        model.fit(history, history.parcels)
        parts.append(target.assign(prediction=np.maximum(0, model.predict(target)).round().astype(int)))
    return pd.concat(parts)


def backtest(frame):
    end = frame.date.max()
    origins = pd.date_range(end - pd.Timedelta(weeks=24) + pd.Timedelta(days=1), end, freq="7D")
    calibration, evaluation = [], []
    for i, origin in enumerate(origins):
        (calibration if i < 12 else evaluation).append(forecast(frame, origin))
    cal = pd.concat(calibration)
    test = pd.concat(evaluation).copy()
    residuals = (cal.parcels - cal.prediction).abs()
    radii = residuals.groupby(cal.depot).quantile(0.9, interpolation="higher")
    radius = test.depot.map(radii).astype(int)
    return test.assign(lower=(test.prediction - radius).clip(lower=0), upper=test.prediction + radius)


def metrics(frame):
    error = (frame.parcels - frame.prediction).abs()
    naive = (frame.parcels - frame.lag7).abs()
    return {"mae": float(error.mean()), "baseline_mae": float(naive.mean()),
            "wape": float(error.sum() / frame.parcels.sum()),
            "coverage": float(frame.parcels.between(frame.lower, frame.upper).mean())}
