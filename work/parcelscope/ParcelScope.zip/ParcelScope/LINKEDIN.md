# Suggested LinkedIn post

How accurately can a depot predict next week’s parcel volume using only what it knows on Monday morning?

I explored that question in ParcelScope, an independent portfolio project built with Python, pandas and scikit-learn. I used three fictional depots and synthetic shipment volumes so the full dataset and workflow can be shared.

My starting benchmark was simple: use last week’s count for the same weekday. In a rolling 12-week evaluation, a ridge regression model reduced mean absolute error from 130 to 60 parcels per depot-day. One result I’d investigate further was uncertainty at the coastal depot. Its forecast band covered only 85.7% of observations against a 90% target.

The project includes an offline interactive dashboard, reproducible data generation, automated tests and a GitHub Actions workflow. One test changes every observed count in the forecast week and verifies that the predictions stay the same.

What benchmark would you use for a depot with frequent short-notice schedule changes?

#DataScience #SoftwareEngineering #LogisticsAnalytics

## Profile project entry

**Title** — ParcelScope | Weekly Parcel Demand Forecasting

**Description** — Independent Python project forecasting seven days of parcel demand across three simulated depots. Evaluated ridge regression against a seasonal benchmark using 252 held-out depot-days. Delivered an interactive dashboard, reproducible build, forecast intervals and automated checks for data leakage.

**Skills** — Python, time-series forecasting, scikit-learn, software testing, data visualisation.

Add your public repository or demo URL when you publish. Adapt the draft to your own voice.
